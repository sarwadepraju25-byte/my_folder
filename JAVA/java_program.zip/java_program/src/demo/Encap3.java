package demo;
import java_program.*;
import java_program1.Encap1;
public class Encap3 extends Encap1 {
	public static void main(String[] arga) {
		Encap3 e = new Encap3();
		//Encap1 e = new Encap1();
		//e.add();
		e.mul();
		//e.sub();
		e.div();
	}

}
