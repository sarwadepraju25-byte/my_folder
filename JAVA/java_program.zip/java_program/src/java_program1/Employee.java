package java_program1;

public class Employee {
	
	void salary() {
		System.out.println("Emplyee salary");
	}
	
	public static void main(String[] args) {
		
		Developer d = new Developer();
		Tester t = new Tester();
		
		d.salary();
		t.salary();
		
	}

}

class Developer extends Employee {
	
	void salary() {
		System.out.println("Developer salary is 50000");
	}
}

class Tester extends Employee {
	
	void salary() {
		System.out.println("Tester salary is 4000");
	}
	
}
