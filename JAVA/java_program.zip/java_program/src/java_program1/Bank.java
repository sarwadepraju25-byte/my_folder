package java_program1;

public class Bank {
	
	void interest() {
		System.out.println("Bank interest is 5%");
	}
	
public static void main(String[] args) {
		
		SBI s = new SBI();
		HDFC h = new HDFC();
		
		s.interest();
		h.interest();
	}

}

class SBI extends Bank {
	
	void interest() {
		System.out.println("SBI interest is 7%");
	}
}

class HDFC extends Bank {
	
	void interest() {
		System.out.println("HDFC interest is 8%");
}
	
	
}
