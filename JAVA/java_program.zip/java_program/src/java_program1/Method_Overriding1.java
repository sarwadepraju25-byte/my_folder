package java_program1;

public class Method_Overriding1  extends Method_Overriding {
	
		  
		 // @Override
		public void add(int a, int b) {
			System.out.println("The addition is: "+(a+b+100));
		}
		  
		//  @Override
		public void add(int s) {
			System.out.println("The p number is: "+(s));
		}
	  
	  
	  
		  
		public static void main(String[] args) {
			
			Method_Overriding1 m = new Method_Overriding1();
			
			m.add(10, 20);
			m.add(50);
			
		}
	  
	  


}
