package java_program1;

public class Encap_Getter_Setter {
	private int a;
	public int getter_a() {
		return a;
	}
	public void setter_a(int c) {
		this.a = c;
	}
	public static void main(String args[]) {
		Encap_Getter_Setter e = new Encap_Getter_Setter();
		e.setter_a(25);
		System.out.println(e.getter_a());
	}

}
