package java_program1;

public class Encap1 {
	int d = 200;
	public int z = 34;
	private int a = 10;
	protected int b = 100;
	
	private void add()
	{
		int m = 90, n = 2;
		System.out.println("Addition is" +(m+n));
	}
	protected void mul()
	{
		int s = 90, t = 2;
		System.out.println("Multiplication is "+(s*t));
	}
	void sub() {
		int x = 10, y = 20;
		System.out.println("Substraction is "+(y-x));
	}
	public void div() {
		int x = 10, y = 5;
		System.out.println("Division is "+(x/y));
	}

}
