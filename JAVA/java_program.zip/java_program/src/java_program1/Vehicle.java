package java_program1;

abstract public class Vehicle {
	abstract void start();
	void stop() {
		System.out.println("Vehicle stopped");
	}
	
public static void main(String[] args) {
		
		
		Car c = new Car();
		c.start();
		c.stop();
	}

 
}

class Car extends Vehicle {
	
	void start() {
		System.out.println("Car start with a key");
	}
}


	
