package java_program1;

public class Person {
	
	

}
