package java_program1;

 class singleInheritance {
	 
	 void  Cat() {
		 System.out.println("Cat inheritance Tiger");
	 }
	 
	 public static void main(String args[]) {
			Pet p = new Pet();
			p.Cat();
			p.Dog();
		}
}
class Pet extends singleInheritance {
	void Dog() {
		System.out.println("Dog inheritance Fox");
	}
	
	
}
