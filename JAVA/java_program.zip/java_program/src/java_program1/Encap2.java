package java_program1;
import java_program1.Encap1;
public class Encap2 extends Encap1 {
	public static void main(String[] args) {
		Encap2 e = new Encap2();
		System.out.println("Value of variable d from class : "+e.d);
		System.out.println("Value of variable z from class : "+e.z);
		System.out.println("Value of variable b from class : "+e.b);
		//System.out.println("Value of variable a from class : "+e.a);
		
		//e.add();
		e.sub();
		e.mul();
		e.div();
	}

}
