package java_program1;

 public class Method_Overriding {
	 
	public void add(int a, int b) {
		System.out.println("The Addition is: "+(a+b));
	}
	public void add(int s) {
		System.out.println("The x number is: "+s);
	}

}

  