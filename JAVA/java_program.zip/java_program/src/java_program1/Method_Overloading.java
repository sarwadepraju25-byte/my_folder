package java_program1;

public class Method_Overloading {
	public void display(int a) {
		System.out.println("Displaying from 1st display method "+ a);
	}
	public void display(char s) {
		System.out.println("Displaying from 2nd display method "+ s);
	}
	
	public void add(int a, double b) {
		System.out.println("Addition is "+(a+b));
	}
	public void add(double m, int n) {
		System.out.println("Addition is "+(m+n));
	}
	
	public void add(int x, int z) {
		System.out.println("Addition is "+(x+z));
	}
	public void add(int x, int z, int y) {
		System.out.println("Addition is "+(x+z+y));
	}
	
	public static void main(String[] args) {
		Method_Overloading M = new Method_Overloading();
		M.display(20);
		M.display('P');
		M.add(30, 12.0);
		M.add(89.7, 70);
		M.add(30, 90);
		M.add(10, 20, 30);
	}

}
