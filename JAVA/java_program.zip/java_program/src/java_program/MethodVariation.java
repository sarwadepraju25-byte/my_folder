package java_program;
import java.util.Scanner;
public class MethodVariation {
	
	public void add(int a, int b) {
		int add = a+b;
		System.out.println("Addition is "+add);
	}
	public int sub(int a, int b)
	{
		int sub = b  - a;
		return sub;
	}
	public void mul() {
		int m = 50 , n = 20;
		System.out.println("Multiplication is "+(m*n));
	}
	public int div() {
		int m = 100, n = 2;
		return(m/n);
	}
	
	public static void main(String srgs[]) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the 1st number");
		int a = sc.nextInt();
		System.out.println("Enter the 2nd number");
		int b = sc.nextInt();
		MethodVariation mv = new MethodVariation();
		mv.add(a, b);
		int s = mv.sub(a, b);
		System.out.println("Substraction is: "+s);
		
		mv.mul();
		int d = mv.div();
		System.out.println("Division is: "+d);
		
		System.out.println("Program is done");
		sc.close();
	}

}
