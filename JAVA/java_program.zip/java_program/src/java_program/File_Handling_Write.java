package java_program;
import java.io.FileWriter;
import java.io.IOException;
public class File_Handling_Write {
	public static void main(String args[]) {
		try {
			FileWriter writer = new FileWriter("sample.txt");
			writer.write("Hello, writing the second line into sample.txt using file handling in java!");
			writer.close();
			System.out.println("Successfully written");
		}catch(IOException e){
			e.printStackTrace();
		}
	}

}
