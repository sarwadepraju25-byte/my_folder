package java_program;

public interface ShapeInterface {
	public void draw();

}
