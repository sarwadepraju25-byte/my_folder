package java_program;
import java.util.Scanner;
public class AreaTriangle implements Area1 , ShapeInterface {
	public void draw() {
		System.out.println("This is a Triangle");
	}
	public void area(double l, double b) {
		double area = 0.5*l*b;
		System.out.println("Area of Triangle: "+area);
	}
	
	public static void main(String args[]) {
		AreaTriangle a = new AreaTriangle();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter length of Triangle: ");
		double l = sc.nextDouble();
		System.out.println("Enter breadth of triangle: ");
		double b = sc.nextDouble();
		a.draw();
		sc.close();
	}

}
