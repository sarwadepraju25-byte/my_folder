package java_program;
import java.util.Scanner;

	// Parent class
	class Greatno1 {
	    public int grt(int a, int b) {
	        if (a > b) {
	            return a;
	        } else if (b > a) {
	            return b;
	        } else {
	            return 0;
	        }
	    }
	}

	// Child class 1
	class PosNegg extends Greatno1 {

	    public void pn(int num) {
	        if (num > 0) {
	            System.out.println("It is a positive number");
	        } else if (num < 0) {
	            System.out.println("It is a negative number");
	        } else {
	            System.out.println("It is zero");
	        }
	    }
	}

	// Child class 2
	class Reversee extends Greatno1 {

	    public void rev(int num) {
	        int temp;
	        int reverse = 0;

	        while (num != 0) {
	            temp = num % 10;
	            reverse = reverse * 10 + temp;
	            num = num / 10;
	        }

	        System.out.println("Reverse number is: " + reverse);
	    }
	}

	// Child class 3
	class Factoriall extends Greatno1 {

	    public void fact(int num) {
	        long factorial = 1;

	        for (int i = 1; i <= num; i++) {
	            factorial = factorial * i;
	        }

	        System.out.println("Factorial of " + num + " is: " + factorial);
	    }
	}

	// Main class
	public class HybridDemo {

	    public static void main(String[] args) {

	        Scanner sc = new Scanner(System.in);

	        System.out.println("Enter the 1st number:");
	        int a = sc.nextInt();

	        System.out.println("Enter the 2nd number:");
	        int b = sc.nextInt();

	        // Object of PosNeg
	        PosNegg p = new PosNegg();

	        // Find greatest number
	        int greatest = p.grt(a, b);

	        if (greatest != 0) {

	            System.out.println("Largest value from " + a + " and " + b
	                    + " is: " + greatest);

	            // Positive / Negative
	            p.pn(greatest);

	            // Object of Reverse
	            Reversee r = new Reversee();
	            r.rev(greatest);

	            // Object of Factorial
	            Factoriall f = new Factoriall();
	            f.fact(greatest);

	        } else {

	            System.out.println("Both numbers are equal.");
	            System.out.println("Positive/Negative, Reverse and Factorial will not be calculated.");
	        }

	        sc.close();
	    
	}
	

}
