package java_program;

public interface Area1 {
	public void area(double a,double b);

}
