package java_program;
import java.util.Scanner;
public class AreaSquare extends Area {
	public void area(double s) {
		double area = s*s;
		System.out.println("Area of Square: "+area);
	}
	public static void main(String arga[]) {
		Area a = new AreaSquare();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter side of square: ");
		double s = sc.nextDouble();
		a.area(s);
		sc.close();
	}

}
