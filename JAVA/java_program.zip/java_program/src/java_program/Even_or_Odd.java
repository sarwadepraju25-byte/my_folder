package java_program;

public class Even_or_Odd extends Greatno {
	public void evenodd(int c){
		if(c % 2 == 0 )
		{
			System.out.println(c+"is Even number");
		}
		else
		{
			System.out.println(c+"is Odd number");
		}
	}	

}