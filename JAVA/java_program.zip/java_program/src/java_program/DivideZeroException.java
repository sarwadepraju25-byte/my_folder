package java_program;
import java.util.Scanner;
public class DivideZeroException {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two numbers");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		int result = 0;
		try {
			result = num1 / num2;
			System.out.println("The result is "+result);
		}
		catch (Exception e) {
			System.out.println("Error found! ! !\n Can't be divideed by Zero"+e.getMessage());
		}
		System.out.println("Good Byeee");
		System.out.println("You are full program is executed successfully");
		sc.close();
	}

}
