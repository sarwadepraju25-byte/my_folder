package java_program;

public abstract class Area {
	


public abstract void area (double x) ; 
}