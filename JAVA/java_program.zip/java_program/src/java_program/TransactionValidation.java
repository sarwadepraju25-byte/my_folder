package java_program;

public class TransactionValidation {
	
	static void validate(int amount) {
		if(amount > 0) {
			System.out.println(amount + " : VALID");
		}
		else
		{
			System.out.println(amount + " : INVALID");
		}
	}
	
	public static void main(String args[]) {
		validate(5000);
		validate(-1000);
		validate(0);
		validate(2500);
	}

}
