package java_program;
import java.util.Scanner;

public class PosNeg extends Greatno{
	public void pn(int grt) 
	{
		if(grt > 0) {
			System.out.println("IT is a positive number");
			
		}
		else
		{
			System.out.println("It is negative number");
		}
	}
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the 1st number");
			int s = sc.nextInt();
			System.out.println("Enter the 2nd number");
			int t = sc.nextInt();
			
			PosNeg o = new PosNeg();
			int grt = o.grt(s, t);
			if(grt != 0) {
				System.out.println("Largest Value from" + s+"and"+ t + "is"+grt);
				//o.evenodd(grt);
				o.pn(grt);
			}
			else
			{
				System.out.println("Both are equal");
				//o.evenodd(grt);
			}
			sc.close();
		}
	

}
