package java_program;

public class ArrayboundException {
	public static void main(String args[]) {
		int a[] = {1,4,12,52,8};
		try {
			for(int i = 0; i <= a.length; i++) {
				System.out.println(a[i]);
			}
		}
		catch (Exception e) {
			System.out.println("Error Fond ! ! !\n Exception occur!"+e.getMessage());
		}
		System.out.println("Good Byeee");
		System.out.println("You are full program is executed successfully");
	}

}
