package java_program;
import java.util.Scanner;
import java.io.*;
public class TransactionValidator {
	public static void main(String args[]) {
		try {
			File transactionFile = new File(".//transaction.txt");
			Scanner scanner = new Scanner(transactionFile);
			FileWriter logWriter = new FileWriter("validation_log.txt");
			System.out.println("Transaction validation Results:");
			while(scanner .hasNextLine()) {
				String line = scanner.nextLine();
				double amount = Double.parseDouble(line);
				if(amount >= 0) {
					logWriter.write(amount + "VALID\n");
					System.out.println("Amount: "+amount+" -> VALID");
				} else {
					logWriter.write(amount + "INVALID\n");
					System.out.println("Amount: "+amount+" -> INVALID");
				}
			}
			scanner.close();
			logWriter.close();
			System.out.println("\nValidation log generated successfully. ");
		} catch(IOException e) {
			System.out.println("File Error: "+ e.getMessage());
		} catch(NumberFormatException e) {
			System.out.println("Error: Invalid number format in file. ");
		}
	}
}


