package java_program;
import java.util.Scanner;
import java.io.*;
public class TransactionFileValidation {
	public static void main(String args[]) {
		try {
			File file = new File(".//transaction.txt");
			Scanner scanner = new Scanner(file);
			System.out.println("Transaction validation Results:");
			while(scanner .hasNextLine()) {
				String line = scanner.nextLine();
				double amount = Double.parseDouble(line);
				if(amount > 0) {
					System.out.println("Amount: "+amount+" -> VALID");
				} else {
					System.out.println("Amount: "+amount+" -> INVALID");
				}
			}
			scanner.close();
		} catch(FileNotFoundException e) {
			System.out.println("Error: transaction.txt file not found. ");
		} catch(NumberFormatException e) {
			System.out.println("Error: Invalid number format in file. ");
		}
	}

}
