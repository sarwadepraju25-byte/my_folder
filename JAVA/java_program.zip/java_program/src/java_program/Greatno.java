package java_program;

public class Greatno {
	public int grt(int a , int b) {
		if(a!=b) {
			if(a>b) {
				return a;
			}
			else
			{
				return b;
			}
		}
		else
		{
			return 0;
		}
			
	}

}
