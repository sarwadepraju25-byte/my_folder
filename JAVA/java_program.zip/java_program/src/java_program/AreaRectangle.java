package java_program;
import java.util.Scanner;
public class AreaRectangle implements Area1 , ShapeInterface {
	public void draw() {
		System.out.println("This is a Rectangle");
	}
	public void area(double l, double b)
	{
		double area = l*b;
		System.out.println("Area of Rectangle: "+area);
	}
	public static void main(String args[]) {
		AreaRectangle a = new AreaRectangle();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter length of Rectangle: ");
		double l = sc.nextDouble();
		System.out.println("Enter breadth of Rectangle: ");
		double b = sc.nextDouble();
		a.draw();
		a.area(l, b);
		sc.close();
		}

}
