package java_program;
import java.io.FileReader;
import java.io.IOException;

public class File_Handling_Read {
	public static void main(String args[]) {
		try
		{
			FileReader reader = new FileReader(".//sample.txt");
			int character;
			
			while((character = reader.read()) != -1) {
				System.out.print((char) character);
			}
			reader.close();
		}
		catch(IOException e) {
			e.printStackTrace();
			
		}
	}

}
