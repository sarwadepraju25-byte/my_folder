package java_program;
import java.util.Scanner;
public class AreaCircle extends Area {
	public void area(double r) {
		double pi = 3.14;
		double area = pi*r*r;
		System.out.println("Area of circle: "+area);
	}
	public static void main(String arga[]) {
		Area a = new AreaCircle();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter radius of circle: ");
		double s = sc.nextDouble();
		//a.area(s);
		sc.close();
	}

}
