package java_program;
import java.util.Scanner;
public class reverse extends Greatno {
	public void rev(int num) {
		int temp, rev=0;
		while(num != 0) {
			temp = num % 10;
			rev= rev * 10 + temp;
			num = num / 10;
		}
		System.out.println("The reverse number is : "+rev);
	}
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); {
			System.out.println("Enter the 1st number");
			int s = sc.nextInt();
			System.out.println("Enter the 2nd number");
			int t = sc.nextInt();
			reverse r = new reverse();
			int grt = r.grt(s, t);
			if(grt != 0) {
				System.out.println("Largest Value from" + s+"and"+ t + "is"+grt);
				//r.evenodd(grt);
				r.rev(grt);
			}
			else
			{
				System.out.println("Both are equal");
				r.rev(grt);
			}
			sc.close();
		}
	
	}
}
