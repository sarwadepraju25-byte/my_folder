package java_program;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Transaction {
	public static void main(String args[]) {
		try {
			File file = new File(".//transactions.csv");
			Scanner sc = new Scanner(file);
			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				System.out.println(line);
			}
			sc.close();
			
		}catch (FileNotFoundException e) {
			System.out.println("csv file not found."+e.getMessage());
		}
	}

}
