package java_program;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CSVTransactionValidation {

	public static void main(String[] args) {
		
		FileReader reader = null;
		FileWriter writer = null;
		
		try {
			// Step 1: Open the input CSV file
			reader = new FileReader(".//transactions.csv");
			
			// Step 2: Create the output CSV file
			writer = new FileWriter(".//validation_results.csv");
			
			System.out.println("CSV files opened successfully.");
			
			// Step 3: Read the complete CSV file
			String csvData = "";
			int character;
			
			while ((character = reader.read()) != -1) {
				csvData = csvData + (char) character;
			}
			
			// Step 4: Split CSV data into individual lines 
			String[] rows = csvData.split("\\r?\\n");
			
			//Step 5: Write output file header
			writer.write("transaction_id,account_no,tranaction_type,amount,validation_result\n");
			
			//Step 6: Process each transaction, skipping header
			for (int i = 1; i < rows.length; i++) {
				
				if(rows[i].trim().isEmpty()) {
					continue;
				}
				
				String[] data = rows[i].split(",");
				
				String transactionId = data[0].trim();
				String accountNo = data[1].trim();
				String transactionType = data[2].trim();
				double amount = Double.parseDouble(data[3].trim());
				
				String result;
				
				//Step 7: Validation transaction details
				if(transactionId.startsWith("TXN") && accountNo.matches("\\d+") && (transactionType.equals("Credit") || transactionType.equals("Debit")) && ((transactionType.equals("Credit") && amount > 0) || (transactionType.equals("Debit") && amount < 0))) {
					
					result = "PASS";
				} else {
					result = "FAIL";
				}
				
				//Step 8: Write validation result to output CSV
				writer.write( transactionId + "," + accountNo + "," + transactionType + "," + amount + "," + result + "\n" );
				
				System.out.println( transactionId + " : " + result );
			}
			
			System.out.println("Validation results written successfully. ");
			
		} catch (IOException e) {
			System.out.println("File error: " + e.getMessage());
		} catch (NumberFormatException e) {
			System.out.println("Invalid transaction amount. ");
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Invalid CSV row format. ");
		}finally {
			
			//Step 9: Close the input file connection
			try {
				if (reader != null) {
					reader.close();
					System.out.println("Input file closed. ");
				}
			}catch (IOException e) {
				System.out.println("Error closing input file. ");
			}
			
			//Step 10: Close the output file connection
			try {
				if (writer != null) {
					writer.close();
					System.out.println("Output file closed. ");
				}
			}catch (IOException e) {
				System.out.println("Error closing output file. ");
			}
		}
		
		System.out.println("Program execution completed. ");

	}

}
