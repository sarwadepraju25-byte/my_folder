package java_program;
import java.util.Scanner;
import java.io.*;
public class CreateFile {
	public static void main(String args[]) throws FileNotFoundException {
		File f = new File("Transaction.txt");
		Scanner sc = new Scanner (f);
		while(sc.hasNextLine())
		{
			System.out.println(sc.nextLine());
		}
		
		System.out.println("File is created");
	   sc.close();
		
	}

}
