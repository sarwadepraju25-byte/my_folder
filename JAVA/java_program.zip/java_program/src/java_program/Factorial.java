package java_program;
import java.util.Scanner;
public class Factorial extends Greatno {
	public void fact(int num) {
		long fact = 1;
		for(int i =1;i<=num;i++) {
			fact = fact * i;
		}
		System.out.println("Factorial number of "+num+" is: "+fact);
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
			System.out.println("Enter the 1st number");
			int a = sc.nextInt();
			System.out.println("Enter the 2nd number");
			int b = sc.nextInt();
			Factorial f = new Factorial();
			int grt = f.grt(a, b);
			if(grt != 0) {
				System.out.println("Largest Value from" + a+"and"+ b + "is"+grt);
				//r.evenodd(grt);
				f.fact(grt);
			}
			else
			{
				System.out.println("Both are equal");
				f.fact(grt);
			}
			sc.close();
	}

}
